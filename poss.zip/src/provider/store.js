import { createContext } from "react";
const Store = createContext()
export default Store